# Data sience ibm course capstone
`Manh Cuong Nguyen`
___

1. Capstone slide
2. Process data on `notebook`
3. Process data on `py` file
4. Dataset